const {GraphQLObjectType, GraphQLString,
    GraphQLSchema, GraphQLID, GraphQLInt, GraphQLList,
GraphQLNonNull} = require('graphql')
var GraphQLDate = require('graphql-date')

// ta dva polja sta za demonstracijo, v nalogi imejte implementirano z bazo (npr. MongoDB)
var novice = [
    { naslov: 'Nobelova nagrada za kemijo za prispevek k razvoju zelene kemične industrije',
      besedilo: 'Znanstveniki so "prevzeli nadzor nad evolucijo in jo uporabili za namene, ki človeštvu prinašajo največje koristi", so navedli na Švedski kraljevi akademiji znanosti. Tlakovali so pot k proizvodnji čistejših novih materialov in biogoriv ter k razvoju inovativnih terapij.',
      vstavljeno: new Date(), id: 1, urednikId: 1 },
    { naslov: 'Prvi posnetki s površja asteroida v zgodovini',
      besedilo: 'Japonska sonda Hajabusa 2 je na površje asteroida uspešno poslala dva skakljajoča roverja. Posnela sta prve fotografije in videoposnetke s tovrstnega nebesnega telesa.',
      vstavljeno: new Date(), id: 2, urednikId: 2 },
    { naslov: 'Holesterol, star 558 milijonov let, razkriva eno od prvih živali na Zemlji',
      besedilo: 'Znanstveniki Avstralske nacionalne univerze (ANU) v Canberri so v starodavnem fosilu v Rusiji našli molekule maščobe, ki potrjujejo, da gre za najstarejšo znano žival, ki je na Zemlji živela pred 558 milijoni let.',
      vstavljeno: new Date(), id: 3, urednikId: 2 },
    { naslov: 'S svetlobnim kladivom povzročili potresu podobne valov',
      besedilo: 'Raziskovalcem z ljubljanske fakultete za strojništvo je v sodelovanju z institucijami iz Kanade in Brazilije uspelo prisluškovati svetlobnim odbojem. Njihovo raziskavo uvrščajo med poskuse, ki so "potisnili klasično znanost čez obzorje".',
      vstavljeno: new Date(), id: 4, urednikId: 2 },
    { naslov: 'Prvi SpaceX-ov potnik okoli Lune bo japonski milijarder',
      besedilo: 'Ameriško zasebno vesoljsko podjetje SpaceX je objavilo ime prvega turista, ki ga bo popeljalo okoli Lune. Gre za japonskega milijarderja, 42-letnega Jusakuja Maezavo, ki naj bi se na pot odpravil leta 2023.',
      vstavljeno: new Date(), id: 5, urednikId: 1 },
];

var uredniki = [
    { ime: 'Janez', priimek: 'Novak', starost: 55, id: 1 },
    { ime: 'Peter', priimek: 'Mlakar', starost: 37, id: 2 },
];

const NovicaType = new GraphQLObjectType({
    name: 'Novica',
    fields: () => ({
        id: {type: GraphQLID},
        naslov: {type: GraphQLString},
        besedilo: {type: GraphQLString},
        vstavljeno: {type: GraphQLDate},
        urednik: {
            type: UrednikType,
            resolve(parent, args, req) {
                console.log(parent)
                console.log(req.userInfo);
                console.log(req.oauth2Error);
                                
                return uredniki.find(t => t.id == parent.urednikId)
            }
        }
    })
})

const UrednikType = new GraphQLObjectType({
    name: 'Urednik',
    fields: () => ({
        id: {type: GraphQLID},
        ime: {type: GraphQLString},
        priimek: {type: GraphQLString},
        starost: {type: GraphQLInt},
        novice: {
            type: new GraphQLList(NovicaType),
            resolve(parent, args, req) {
                // preveru userja za role in scope
                //console.log(parent)
                console.log(req);
                
                return novice.filter(t => t.urednikId == parent.id)
            }
        }
    })
})

const RootQuery = new GraphQLObjectType({
    name: 'RootQueryType',
    fields: {
        novica: {
            type: NovicaType,
            args: {id: {type: GraphQLID}},
            resolve(parent, args) {
                return novice.find(t => t.id == args.id)
            },
        },
        novicaByNaslov: {
            type: new GraphQLList(NovicaType),
            args: {name: {type: GraphQLString}},
            resolve(parent, args) {
                //console.log(res)
                return novice.find(t => t.naslov.includes(args.name))                
            },
        },
        urednik: {
            type: UrednikType,
            args: {id: {type: GraphQLID}},
            resolve(parent, args) {
                return uredniki.find(t => t.id == args.id) 
            },
        },
        novice: {
            type: new GraphQLList(NovicaType),
            resolve(parent, args) {
                return novice
            }
        },
        uredniki: {
            type: new GraphQLList(UrednikType),
            resolve(parent, args) {
                return uredniki
            }
        }
    }
})

const Mutations = new GraphQLObjectType({
    name: "Mutation",
    fields: {
        vstaviUrednika: {
            type: UrednikType,
            args: {
                ime: {type: new GraphQLNonNull(GraphQLString)},
                priimek: {type: new GraphQLNonNull(GraphQLString)},
                starost: {type: new GraphQLNonNull(GraphQLInt)},
            },
            resolve(parent, args) {
                let urednik = {
                    ime: args.ime,
                    priimek: args.priimek,
                    starost: args.starost,
                    id: uredniki.length+1,
                }
                uredniki.push(urednik);
                
                return urednik
            }
        },
        vstaviNovico: {
            type: NovicaType,
            args: {
                naslov: {type: new GraphQLNonNull(GraphQLString)},
                besedilo: {type: new GraphQLNonNull(GraphQLString)},
                urednikId: {type: new GraphQLNonNull(GraphQLID)},
            },
            resolve(parent, args) {
                let novica = {
                    naslov: args.naslov,
                    besedilo: args.besedilo,
                    vstavljeno: new Date(),
                    id: novice.length+1,
                    urednikId: args.urednikId,
                }
                novice.push(novica)
                return novica
            }
        }
    }
})

module.exports = new GraphQLSchema({
    query: RootQuery,
    mutation: Mutations,
})