const express = require("express")
const router = express.Router()

router.get('/novice', async (req, res) => {
    // v req.user še lahko dodatno preverimo vlogo in zavrnemo dostop
    console.log("/novice -> " + JSON.stringify(req.user));
    
    // ker imamo dostop do userja, lahko vrnemo resource (npr. novice) samo za tega userja, če želimo

    res.send([
        {id:1, naziv:"Novo leto", opis:"Novo leto je bilo lepo."},
        {id:2, naziv:"Plavanje", opis:"V plavaju je zmagal Phelps!"},
    ]);
})

module.exports = router